#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2024, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
This module contains the connection for the SCiLSLab rest API.
"""

from functools import total_ordering
import inspect
import re
import time
import weakref

import requests

from scilslab import _cppserialization

@total_ordering
class _APIVersion():
    def __init__(self, major: int, minor: int):
        self.major = int(major)
        self.minor = int(minor)

    @classmethod
    def from_version_string(cls, version_string):
        pattern = re.compile(r"SCiLS REST API v(\d+)\.(\d+)")
        match_result = pattern.search(version_string)
        if match_result is not None:
            return cls(int(match_result[1]), int(match_result[2]))

        return cls(0,0)

    def _is_valid_operand(self, other):
        return hasattr(other, "major") and hasattr(other, "minor")

    def __eq__(self, other):
        if not self._is_valid_operand(other):
            return NotImplemented
        return (self.major, self.minor) == (other.major, other.minor)

    def __lt__(self, other):
        if not self._is_valid_operand(other):
            return NotImplemented
        return (self.major, self.minor) < (other.major, other.minor)




class _Connection:
    """Class representing the connection to a SCILS REST API server
    """

    def __init__(
        self,
        authentication_token,
        hostname,
        port,
        retries,
        sleep,
        tls,
        verify
    ):
        """Create a connection to the API server

        Args:
            authentication_token (str): an authentication token required by the
                server to enable connection. The server issues a bearer
                authentication token at startup and accepts connection only
                from clients providing this bearer token.
            address (str): the server hostname or ip address.
            port (int): the port to connect to.
            retries (int): number of retries when a request fails and no
                response was received by the server. Set to 0 to disable,
                set to 1 or larger to circumvent idle connection issues.
            sleep (float): sleep time between retries in seconds.
            tls (bool): Specifies if this is a tls secured connection.
            verify: Either a boolean, in which case it controls whether
                the server's TLS certificate is verified ot a string, in which
                case it must be a path to a CA bundle to use.
        """

        self._sleep = max(sleep, 0)
        self._retries = max(retries, 0)
        
        self._session = requests.Session()
        self._finalizer = weakref.finalize(self, _Connection._close_session, self._session)

        self._session.headers.update({"Authorization": "Bearer {}".format(authentication_token)})
        self._session.verify = verify
        
        if tls is True:
            self._base_url = "https://{}:{}/".format(hostname, port)
        else:
            self._base_url = "http://{}:{}/".format(hostname, port)

        try:
            self._server_version = self.test_connection()
        except ConnectionError:
            if "localhost" in hostname:
                self._base_url = self._base_url.replace("localhost", "127.0.0.1", 1)
            self._server_version = self.test_connection()

        self._versioned_base_url = self._base_url + "v{}/".format(_cppserialization.apiMajorVersion())

        self._client_version = _cppserialization.apiVersionString()
        self.check_api_compatibility()

    def get(self, route, params=None, include_caller_in_errormessage=True):
        """Get request to the API server

        Args:
            route (string): The route to be called
            data (bytes, optional): Data to be sent. Defaults to None.
            json (Dict, optional): A dictionary that will be serialized to
                json for the request. Defaults to None.
            include_caller_in_errormessage (bool, optional): Defines
                if the name of the calling function shall be included in the error message
                for a failed request. Defaults to True.

        Returns:
            requests.Response: The response of the request.
        """
        if include_caller_in_errormessage:
            callers_name = inspect.currentframe().f_back.f_code.co_name
        else:
            callers_name = ""

        return self._request('GET', route, params, data=None, json=None, callers_name=callers_name)

    def post(self, route, params=None, data=None, json=None):
        """Post request to API server

        Args:
            route (string): The route to be called
            data (bytes, optional): Data to be sent. Defaults to None.
            json (Dict, optional): A dictionary that will be serialized to
                json for the request. Defaults to None.

        Returns:
            requests.Response: The response of the request.
        """
        callers_name = inspect.currentframe().f_back.f_code.co_name
        return self._request('POST', route, params, data, json, callers_name)

    @staticmethod
    def _close_session( session: requests.Session):
        session.close()

    def _request(self, verb, route, params, data, json, callers_name):

        retry_count = self._retries
        while True:
            try:
                response = self._session.request(
                    verb,
                    self._get_url(route),
                    params=params,
                    data=data,
                    json=json,
                    )

            except requests.ConnectionError as err:
                if retry_count > 0:
                    retry_count -= 1
                    time.sleep(self._sleep)
                    continue
                else:
                    raise ConnectionError(str(err)) from None

            try:
                response.raise_for_status()
                return response

            except requests.HTTPError as err:
                if callers_name != "":
                    message = "The request for {} failed with error message: {}".format(
                        callers_name, response.text)
                else:
                    message = response.text
                raise ValueError(message) from None


    def _get_url(self, route):
        if route != "version":
            return self._versioned_base_url + route

        return self._base_url + route

    def get_server_version(self):
        """
        Returns:
            str: The string with the API version utilized by the server.
        """
        response = self.get("version", include_caller_in_errormessage=False)
        return response.text

    def test_connection(self):
        """Test connection to the server.

        Test if a connection to the server can be established and return
        the version if the server in case of success.

        Raises:
            ConnectionError: If the connection to the API server fails

        Returns:
            string: The API version of the server
        """
        try:
            return self.get_server_version()
        except ValueError as err:
            msg = "Cannot establish a working connection to the SCiLSLab server."
            error = str(err)

            if error:
                msg += " A test request returned with error: {}".format(
                    error)
            raise ConnectionError(msg) from err

    def check_api_compatibility(self):
        """Check client and server compatibility
        
        Check if the client and server use the same API major version

        Raises:
            ValueError: If client and server use different major versions
        """
        server_version = _APIVersion.from_version_string(self._server_version)
        client_version = _APIVersion.from_version_string(self._client_version)

        if server_version.major != client_version.major:
            message = "ERROR: Client and Server use different API major versions."
            message += " Client {}. Server {}.".format(
                self._client_version, self._server_version
            )
            raise ValueError(message)
