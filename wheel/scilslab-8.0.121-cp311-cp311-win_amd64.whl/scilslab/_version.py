__version__ = "8.0.121"
_scilslib = "58.0.12104"
_commit = "fd305b7b79901531b1026a284fdeb80f86654680"
