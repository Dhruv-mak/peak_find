#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2024, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
import os
from unittest.mock import patch
import unittest
import warnings

from scilslab.client import DatasetProxy

from scilslab.session import LocalSession
from scilslab.session import _APIVersion
from scilslab.session import _raise_startup_warnings
from scilslab._tests.utils import CerebellaUUIDs
from scilslab._tests.utils import ScilsLabTestCase

class TestSession(ScilsLabTestCase):
    """
    A test class for the session wrapper.
    """
    def setUp(self):
        self._temp_dataset = self.temporaryDatasetFromArchive('cerebella.tar.gz')
        self._filename = self._temp_dataset.slx

    def tearDown(self):
        self._temp_dataset.cleanup()

    def test_wrong_parameters(self):
        """ Test that we make some basic parameter check """
        # Non existing path.
        with self.assertRaises(ValueError):
            LocalSession(filename='foo')

        # Valid file but no default executable found.
        with patch('scilslab.session._find_executable', return_value=None):
            with self.assertRaisesRegex(
                    ValueError, "An executable was not provided*"):
                LocalSession(filename=self._filename)

        # Check the wrong executable error.
        with self.assertRaisesRegex(ValueError, "An executable was provided but*"):
            LocalSession(filename=self._filename, executable='foo')

    def test_construction(self):
        """ Test that we can construct a session object succesfully """
        # Test with the explicit construction and close().
        session = LocalSession(self._filename)
        # Test that the server process is alive.
        self.assertIsNone(session.process.poll())
        # Retrieve the client and test that it is working.
        client = session.dataset_proxy
        self.assertIn('SCiLS REST', client.get_server_version())
        # Close the session and check that the clean-up is done.
        session.close()
        self.assertIsNotNone(session.process.poll())

    def test_as_context_manager(self):
        """ Test that we can start a session as context manager """
        with LocalSession(self._filename) as session:
            # Test that the server process is alive.
            self.assertIsNone(session.process.poll())
            # Retrieve the client and test that it is working.
            client = session.dataset_proxy
            self.assertIn('SCiLS REST', client.get_server_version())
        # Check that the cleanup is done properly upon exit.
        self.assertIsNotNone(session.process.poll())

    def test_wrong_path_env(self):
        """ Test that the wrong path in the environment variable raises """
        old_value = os.environ.get('SCILSMSSERVER')
        try:
            os.environ['SCILSMSSERVER'] = 'foo'
            with self.assertRaisesRegex(ValueError, "The path *"):
                LocalSession(filename=self._filename)
        finally:
            if old_value is not None:
                os.environ['SCILSMSSERVER'] = old_value

    def test_non_default_port(self):
        """ Test that we can start a session with non-default ports """
        non_default_ports = [8000, 8080]
        for port in non_default_ports:
            with LocalSession(self._filename, port=port) as session:
                # Test that the server process is alive.
                self.assertIsNone(session.process.poll())
                # Retrieve the client and test that it is working.
                client = session.dataset_proxy
                self.assertIn('SCiLS REST', client.get_server_version())

    def test_connection_error(self):
        """ Test that in case of connection error we get a proper error """
        # If we get ConnectionError, we keep trying and finally
        # give up and re-raise with an error message.
        with patch('scilslab._connection._Connection.get_server_version') as mock_connection:
            mock_connection.side_effect = ConnectionError("A test error")
            with self.assertRaisesRegex(
                    ConnectionError,
                    "Cannot start session. "
                    "Attempt to create the dataset proxy failed*"):
                LocalSession(filename=self._filename, timeout=90, retries=0)

    def test_multiple_sessions_same_port(self):
        """ Test that we can not start multiple sessions on the same port """
        port = 8087
        temp_dataset = self.temporaryDatasetFromArchive('OneTwoThree.tar.gz')
        with LocalSession(temp_dataset.slx, port=port, retries=0) as session:
            client = session.dataset_proxy
            self.assertIn('SCiLS REST', client.get_server_version())
            with self.assertRaisesRegex(
                    RuntimeError, "Cannot start the server*"):
                LocalSession(self._filename, port=port, retries=0)

        temp_dataset.cleanup()

    def test_locale_support(self):
        """ Test umlauts in filename or folder """
        # Create the test file location with umlauts
        temp_dataset = self.temporaryDatasetFromArchive(
            "cerebella.tar.gz",
            rename_to = 'öäüöäü',
            tempdir_suffix = 'ää')
            
        with LocalSession(temp_dataset.slx) as session:
            client = session.dataset_proxy
            self.assertIn("SCiLS REST", client.get_server_version())
            # Retrieve some known quantities and do a sanity check.
            spots = client.get_region_spots(
                region_id=CerebellaUUIDs.region_measurement1)
            self.assertEqual(len(spots["spot_id"]), 1132)
            normalizations = client.get_normalizations()
            for entry in ["Median", "Total Ion Count", "Root Mean Square"]:
                self.assertIn(entry, normalizations.values())

        temp_dataset.cleanup()

    def test_invalid_dongle_license(self):
        """ Test that we can not start a session with an invalid dongle license serial """
        with self.assertRaisesRegex(
                RuntimeError,
                "Cannot start server.*Provided serial key foo is not valid.*"):
            LocalSession(
                self._filename,
                timeout=90,
                license_serial="foo")

    def test_invalid_wibu_license(self):
        """ Test that we can not start a session with an invalid wibu license serial """
        with self.assertRaisesRegex(
                RuntimeError,
                "Cannot start server.*Provided serial key 130-123456789-16 cannot be found.*"):
            LocalSession(
                self._filename,
                timeout=90,
                license_serial="130-123456789-16")

    def test_connection_fails_for_api_mismatch(self):
        """ Test connection to a Server with a different API version """
        with patch('scilslab._connection._Connection.check_api_compatibility') as mock_connection:
            mock_connection.side_effect = ValueError("ERROR")
            # Connection should fail.
            with self.assertRaisesRegex(ValueError, "ERROR*"):
                LocalSession(
                    self._filename,
                    timeout=90)

    def test_timeout_works(self):
        with patch.object(
            LocalSession,
            '_build_command_line',
            # Execute 10 pings instead of starting the server
            # to force timeout
            return_value = ['ping','127.0.0.1','-n', '10']):
            
            with self.assertRaisesRegex(
                RuntimeError,
                r"Timeout during startup\. Try to increase the timeout"):
                LocalSession(
                    self._filename,
                    timeout = 2
                    )

    def test_server_startup_fails_without_proper_error_output_works(self):
        with patch.object(
            LocalSession,
            '_build_command_line',
            # Execute 2 pings instead of starting the server
            # to simulate a server process that fails without giving
            # a proper [ERROR] output
            return_value = ['ping','127.0.0.1','-n', '2']):
            
            with self.assertRaisesRegex(
                RuntimeError,
                "Cannot obtain server status."):
                LocalSession(
                    self._filename,
                    timeout = 5
                    )

    def test_close_with_already_dead_server_works(self):
        temp_dataset = self.temporaryDatasetFromArchive('OneTwoThree.tar.gz')
        session = LocalSession(temp_dataset.slx)
        session.process.terminate()
        session.process.wait(timeout=20)
        try:
            session.close()
        except:
            self.fail("Close raised an exception")

        temp_dataset.cleanup()

    def test_local_session_does_not_start_if_server_has_higher_major_version(self):
        current_version = _APIVersion.from_version_string(DatasetProxy.client_version)
        with patch.object(
                LocalSession,
                '_executable_version',
                return_value=_APIVersion(current_version.major + 1 , 0)):
            with self.assertRaisesRegex(
                    RuntimeError,
                    "The API server executable is not compatible with the installed scilslab package"):
                LocalSession(
                    filename=self._filename,
                    retries=2,
                    port=8090)

    def test_local_session_starts_if_server_has_higher_minor_version(self):
        current_version = _APIVersion.from_version_string(DatasetProxy.client_version)
        with patch.object(
                LocalSession,
                '_executable_version',
                return_value=_APIVersion(current_version.major, current_version.minor + 1)):
            with LocalSession(
                    filename=self._filename,
                    retries=2,
                    port=8090) as session:
                client = session.dataset_proxy
                self.assertIn("SCiLS REST", client.get_server_version())
                

class FileMigration(ScilsLabTestCase):
    """
    A test class for the session wrapper.
    """
    def setUp(self):
        self._temp_dataset = self.temporaryDatasetFromArchive('OneTwoThree_old_schema.tar.gz')
        self._filename = self._temp_dataset.slx

    def tearDown(self):
        self._temp_dataset.cleanup()

    def test_old_data_with_default_setting_raises(self):
        with self.assertRaisesRegex(
                RuntimeError,
                ".*The dataset has a deprecated internal data structure.*"):
            LocalSession(
                filename=self._filename,
                retries=2,
                port=8090)

    def test_old_data_with_explicit_no_migration_setting_raises(self):
        with self.assertRaisesRegex(
                RuntimeError,
                ".*The dataset has a deprecated internal data structure.*"):
            LocalSession(
                filename=self._filename,
                retries=2,
                port=8090,
                auto_migrate_files=False)

    def test_migration_with_default_creates_backup(self):
        with LocalSession(
                filename=self._filename,
                retries=2,
                port=8090,
                auto_migrate_files=True) as session:
            client = session.dataset_proxy
            self.assertIn("SCiLS REST", client.get_server_version())
            self.assertIn(
                '[INFO] File needs migration and will be automatically migrated',
                session.server_log)
            self.assertIn(
                'A backup copy of the file will be created before migration',
                session.server_log)

            self.assertEqual(
                len([x for x in os.listdir(self._temp_dataset.directory_name) if x.endswith('.backup')]), 
                1)

    def test_migration_with_explicit_backup_creates_backup(self):
        with LocalSession(
                filename=self._filename,
                retries=2,
                port=8090,
                auto_migrate_files=True,
                backup_upon_migration=True) as session:
            client = session.dataset_proxy
            self.assertIn("SCiLS REST", client.get_server_version())

            self.assertEqual(
                len([x for x in os.listdir(self._temp_dataset.directory_name) if x.endswith('.backup')]), 
                1)

    def test_migration_without_backup_creates_no_backup(self):
        with LocalSession(
                filename=self._filename,
                retries=2,
                port=8090,
                auto_migrate_files=True,
                backup_upon_migration=False) as session:
            client = session.dataset_proxy
            self.assertIn("SCiLS REST", client.get_server_version())

            self.assertEqual(
                len([x for x in os.listdir(self._temp_dataset.directory_name) if x.endswith('.backup')]), 
                0)
                
    def test_migration_with_backup_with_old_server_raises1(self):
        with patch.object(
                LocalSession,
                '_executable_version',
                return_value=_APIVersion(0,0)):
            with self.assertRaisesRegex(
                    RuntimeError,
                    "Automatic migration of files with backup requires at least server version 5.1"):
                LocalSession(
                    filename=self._filename,
                    retries=2,
                    port=8090,
                    auto_migrate_files=True)

    def test_migration_with_backup_with_old_server_raises2(self):
        with patch.object(
                LocalSession,
                '_executable_version',
                return_value=_APIVersion(0,0)):
            with self.assertRaisesRegex(
                    RuntimeError,
                    "Automatic migration of files with backup requires at least server version 5.1"):
                LocalSession(
                    filename=self._filename,
                    retries=2,
                    port=8090,
                    auto_migrate_files=True,
                    backup_upon_migration=True)

    def test_migration_without_backup_with_old_server_works(self):
        with patch.object(
                LocalSession,
                '_executable_version',
                return_value=_APIVersion(0,0)):
            with LocalSession(
                    filename=self._filename,
                    retries=2,
                    port=8090,
                    auto_migrate_files=True,
                    backup_upon_migration=False) as session:
                client = session.dataset_proxy
                self.assertIn("SCiLS REST", client.get_server_version())

            # The command line setting used for automigration on old server
            # lead to a backup copy with current server
            self.assertEqual(
                len([x for x in os.listdir(self._temp_dataset.directory_name) if x.endswith('.backup')]), 
                1)

    def test_auto_migrate_files_must_be_boolean(self):
        with self.assertRaisesRegex(ValueError,
            "'auto_migrate_files' must be of type bool."):
            LocalSession(
                filename=self._filename,
                retries=2,
                port=8090,
                auto_migrate_files="",
                backup_upon_migration=False
            )

    def test_backup_upon_migration_must_be_boolean(self):
        with self.assertRaisesRegex(ValueError,
            "'backup_upon_migration' must be of type bool."):
            LocalSession(
                filename=self._filename,
                retries=2,
                port=8090,
                auto_migrate_files=True,
                backup_upon_migration=""
            )

class TestWarningOnStartup( unittest.TestCase):

    def test_one_warning(self):
        serverlog = "[INFO] Info 1\n[INFO] Info2\n [WARNING] Warning 1\n[INFO] Info3"
        with warnings.catch_warnings(record=True) as w:
            _raise_startup_warnings(serverlog)
            self.assertEqual(len(w), 1)
            self.assertIsInstance(w[0].message, UserWarning)
            self.assertEqual(str(w[0].message), ' Warning 1')

    def test_two_warnings(self):
        serverlog = "[INFO] Info 1\n[INFO] Info2\n [WARNING] Warning 1\n[INFO] Info3\n[WARNING]Warning 2"
        with warnings.catch_warnings(record=True) as w:
            _raise_startup_warnings(serverlog)
            self.assertEqual(len(w), 2)
            self.assertIsInstance(w[0].message, UserWarning)
            self.assertEqual(str(w[0].message), ' Warning 1')
            self.assertIsInstance(w[1].message, UserWarning)
            self.assertEqual(str(w[1].message), 'Warning 2')

    def test_no_warning(self):
        serverlog = "[INFO] Info 1\n[INFO] Info2\n[INFO] Info3"
        with warnings.catch_warnings(record=True) as w:
            _raise_startup_warnings(serverlog)
            self.assertEqual(len(w), 0)
                
if __name__ == '__main__':
    unittest.main()
