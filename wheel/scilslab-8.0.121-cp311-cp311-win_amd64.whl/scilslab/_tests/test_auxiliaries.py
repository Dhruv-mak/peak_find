#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2024, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
import unittest

from scilslab.session import _APIVersion

class TestAPIVersion(unittest.TestCase):

    def test_creation_of_API_version_from_string(self):
        self.assertEqual(
            _APIVersion.from_version_string("SCiLS REST API v5.0"),
            _APIVersion(5, 0))

        self.assertEqual(
            _APIVersion.from_version_string("SCiLS REST API v5.3"),
            _APIVersion(5, 3))

        self.assertEqual(
            _APIVersion.from_version_string("SCiLS REST API v25.43"),
            _APIVersion(25, 43))

        self.assertEqual(
            _APIVersion.from_version_string("[ERROR] unknown command line parameter"),
            _APIVersion(0, 0))

        self.assertEqual(
            _APIVersion.from_version_string(""),
            _APIVersion(0, 0))

    def test_version_comparisons(self):

        self.assertTrue(
            _APIVersion( 4, 5) == _APIVersion(4, 5))

        self.assertFalse(
            _APIVersion( 5, 5) == _APIVersion(4, 5))

        self.assertFalse(
            _APIVersion( 4, 5) == _APIVersion(4, 6))

        self.assertTrue(
            _APIVersion( 4, 5) < _APIVersion(5, 5))

        self.assertTrue(
            _APIVersion( 4, 5) < _APIVersion(4, 6))

        self.assertFalse(
            _APIVersion( 4, 5) < _APIVersion(4, 5))

        self.assertFalse(
            _APIVersion( 5, 5) < _APIVersion(4, 5))

        self.assertFalse(
            _APIVersion( 4, 5) < _APIVersion(4, 4))

        self.assertTrue(
            _APIVersion( 4, 5) >= _APIVersion(4, 5))

        self.assertTrue(
            _APIVersion( 5, 5) >= _APIVersion(4, 5))

        self.assertTrue(
            _APIVersion( 4, 6) >= _APIVersion(4, 5))

        self.assertFalse(
            _APIVersion( 4, 5) >= _APIVersion(4, 6))

        self.assertFalse(
            _APIVersion( 4, 5) >= _APIVersion(5, 5))
