#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2024, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
This module contains the feature table interface for the SCiLSLab rest API.
"""

import pathlib

import numpy
import pandas as pd

from scilslab import _cppserialization
from scilslab._connection import _Connection

class OpticalImageProxy:
    """
    The OpticalImageProxy class contains the methods to read and write
    optical images from and to a data set provided by a server.
    This object is not intended to be instantiated on its own, rather it is
    instantiated by the DatasetProxy, the instance can be retrieved through
    the dataset proxy.
    """

    def __init__(
            self,
            connection: _Connection,
            ):
        """
        Create a dataset proxy and connect to a SCiLSLab server.

        Args:
            connection: The API client connection
        """
        self._connection = connection


    def get_ids(self):
        """Get a table of optical images in a SCiLS lab dataset

        Returns:
            pandas.DataFrame: DataFrame with 4 columns
                id: The unique identifier of the optical image
                name: The name of the optical image
                type: The type of the optical image
                date: The date when the optical image was
                added to the dataset.
                has_external_image: A boolean that indicates
                if the image contains a reference to an
                external optical image
                The order of the rows is unspecified.
        """
        response = self._connection.get('opticalimagetable')
        return _cppserialization.deserializeOpticalImageTable(response.content)
        
    def get_image(self, optical_image_id, lightweight = False):
        """Retrieve an optical image from a SCiLS Lab dataset.

        Retrieves the optical image binary data (if lightweight is not False)
        and associated information such as name, type, world-to-pixel transformation
        matrix and the associated spot list of the image.

        Args:
            optical_image_id (string): The unique identifier of the optical image.
            lightweight (bool, optional): If set, the returned object will
                not contain the binary image data. Defaults to False.

        Returns:
            :obj:`OpticalImage`:
                An object that contains the name, type,
                world-to-pixel transformation matrix, binary data and the
                spotlist for the image.
        """
        params = {
            'opticalimageid': optical_image_id,
            'lightweight': lightweight
        }
        response = self._connection.get('opticalimage', params=params)
        return _cppserialization.deserializeOpticalImage(response.content)


    def write_image(
        self,
        data,
        px2world,
        reference_bitmap_id=None,
        name=None,
        image_type=None):
        """Write an optical image into a SCiLS Lab dataset

        Writes an optical image into a SCiLS Lab dataset.

        Note:
            Optical Images in SCILS Lab are associated with a
            spot list of mass spectra. The reference_bitmap_id
            specifies from which optical image the new image inherits
            the spot list. This should be the unique identifier of the optical image that
            was used to register the new image.

        Note:
            The SCiLS Lab API does not check if the provided binary data
            or file represent a valid bitmap image of an allowed type.
            This check will be performed the first time the dataset is opened
            in SCiLS Lab. Invalid optical images will subsequently by removed
            from the dataset.

        Args:
            data: Either a binary blob of the bitmap image data or a
                path-like object that specifies a file.
                It can be a png, a tiff, a jpeg, a svg or a
                bmp image. Maximum size is 1e10 bytes.
            px2world (iterable of float):  A representation of the
                4x4 transformation matrix that transforms pixels of the
                optical image into the world coordinates of the
                SCiLS Lab dataset. Typically this is represented
                as a 4x4 numpy array, it can also be an iterable
                of 16 elements in row major order.
            reference_bitmap_id (string, optional): The unique identifier of the optical
                reference image in SCiLS Lab. If None or "", no reference
                image is specified. Defaults to None.
            name (string, optional): The name of the optical image. If data is
                of type bytes, the name must be specified, otherwise it
                will be inferred from the filename. Defaults to None
            image_type (string, optional): The type of the optical image. If
                data is of type bytes the type must be specified, otherwise
                it will be inferred from the file extension. Defaults to None

        Raises:
            ValueError: If the input is incorrect or writing of the
                optical image fails.

        Returns:
            :obj:`string`: The unique identifier of the newly written image.
        """

        if reference_bitmap_id is None:
            reference_bitmap_id = ""

        if type(data) is not bytes:
            try:
                p = pathlib.Path(data)
            except Exception as err:
                raise ValueError(
                    'Data is neither a bytes object nor can it be interpreted as path.')  from err

            if not p.exists():
                raise ValueError("The file '{}' specified by 'data' does not exist.".format(str(p)))

            if p.suffix == '':
                raise ValueError("The specified file {} has no extension.".format(str(p)))
            image_type = p.suffix
            data = p.read_bytes()
            name = p.stem
        else:
            if name is None or name == "":
                raise ValueError("If data is of type bytes, a name must be specified")

            if image_type is None or image_type == "":
                raise ValueError("If data is of type bytes, an image_type must be specified")

        tmat = numpy.asanyarray(px2world, dtype=numpy.double).flatten()
        if len(tmat) != 16:
            raise ValueError(
                " 'px2world' has incorrect format: Must be an iterable with 16 elements"
            )

        data = _cppserialization.serializeOpticalImage(data, tmat, reference_bitmap_id, name, image_type)
        response = self._connection.post('opticalimage', data=data)
        return response.text
