SCiLS REST API
==============

The `scilslab` package is a python wrapper for the `SCiLS REST API`, and it is intended to give `SCiLS
<https://www.bruker.com/products/mass-spectrometry-and-separations/ms-software/scils.html>`_
users the full flexibility
in working with their mass spectrometry imaging data.

The package is distributed as a source distribution `scilslab-<version>.tar.gz` and as precompiled wheels
for current versions of Python under Windows. You should have received a copy
of the documentation along with the package.

Wheels that are provided with SCiLS Lab contain a `requirements.txt` file in the wheel metadata.
This file lists the exact versions of the external dependencies that were used to
build and test the wheel.

© Copyright 2020 - 2024, Bruker Daltonics GmbH & Co. KG \
For Research Use Only - not for use in clinical diagnostic procedures. \
Contact: support.scils@bruker.com
